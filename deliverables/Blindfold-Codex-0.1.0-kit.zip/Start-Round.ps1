param(
    [string]$Workspace,
    [string]$Resume,
    [string]$Language,
    [string]$AdbPath,
    [string]$CodexPath
)
$ErrorActionPreference = 'Stop'

if (-not $Workspace) { $Workspace = (Read-Host 'Path to the dedicated round folder').Trim('"') }
if (-not (Test-Path -LiteralPath $Workspace -PathType Container)) { throw 'Choose an existing round folder.' }

if (-not $AdbPath) {
    $adbCommand = Get-Command adb.exe -ErrorAction SilentlyContinue
    if ($adbCommand) { $AdbPath = $adbCommand.Source }
}
if (-not $AdbPath) {
    $locations = @(
        "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe",
        "$env:TEMP\island-android-toolchain\sdk\platform-tools\adb.exe"
    )
    if ($env:ANDROID_HOME) { $locations = @("$env:ANDROID_HOME\platform-tools\adb.exe") + $locations }
    $AdbPath = $locations | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}
if (-not $AdbPath) { throw 'Install Android SDK Platform-Tools and add adb to PATH.' }

if (-not $CodexPath) {
    $standalone = "$env:LOCALAPPDATA\BlindfoldCodex\cli\node_modules\@openai\codex-win32-*\vendor\*-pc-windows-msvc\bin\codex.exe"
    $CodexPath = Get-ChildItem -Path $standalone -File -ErrorAction SilentlyContinue |
        Select-Object -First 1 -ExpandProperty FullName
}

& $AdbPath -d reverse tcp:18763 tcp:18763
if ($LASTEXITCODE -ne 0) { throw 'Connect one Android phone by USB and allow USB debugging on the phone.' }

try {
    $bridgeArgs = @((Join-Path $PSScriptRoot 'bridge.py'), '--workspace', (Resolve-Path -LiteralPath $Workspace).Path)
    if ($Resume) { $bridgeArgs += @('--resume', $Resume) }
    if ($Language) { $bridgeArgs += @('--language', $Language) }
    if ($CodexPath) { $bridgeArgs += @('--codex', $CodexPath) }
    & python @bridgeArgs
    if ($LASTEXITCODE -ne 0) { throw 'The round bridge exited with an error.' }
} finally {
    & $AdbPath -d reverse --remove tcp:18763
}
