import argparse
import asyncio
from collections import deque
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import queue
import secrets
import sys
import threading
import time

from codex_rpc import CodexRpc
from headset import Headset, Utterance

PORT = 18763
VOICE_INSTRUCTIONS = (
    'The user is working blindfolded with a headset. Follow their coding instructions. '
    'Give brief, plain-language progress updates and responses suitable for listening. '
    'For status questions distinguish completed work, work still underway, and blockers. '
    'Say which checks actually ran. Leave code and detailed logs in the workspace.'
)


class Round:
    def __init__(self, headset):
        self.headset = headset
        self.mode = 'idle'
        self.cue = ''
        self.revision = 0
        self.last_ping = 0
        self.thread_id = None
        self.rpc = None
        self.connected = True
        self.capture = None
        self.dictation = []
        self.utterance = Utterance()
        self.heard = None
        self.playback = deque()
        self.speaker = None
        self.prompts = deque()
        self.dispatcher = None
        self.running = False
        self.latest_progress = ''

    def update(self, mode=None, cue=''):
        if mode is not None:
            self.mode = mode
        self.cue = cue
        self.revision += 1

    async def request(self, route):
        self.last_ping = time.monotonic()
        try:
            if self.connected and self.mode == 'idle' and route in {'/dictation/start', '/voice/start'}:
                self.headset.open()
                self.dictation = []
                self.utterance.reset()
                mode = route.split('/')[1]
                self.update(mode, mode)
                self.capture = asyncio.create_task(self.listen())
                if mode == 'voice':
                    self.say('Voice on. ' + (self.progress() if self.running else
                             self.latest_progress or 'Ask a question, then pause.'))
            elif self.mode == 'dictation' and route == '/dictation/stop':
                self.finish_dictation()
            elif self.mode == 'voice' and route == '/voice/stop':
                self.stop_audio('stop')
        except Exception as error:
            self.report_error(error)
            self.stop_audio('error')
        return {'mode': self.mode if self.connected else 'offline', 'cue': self.cue, 'revision': self.revision}

    def stop_audio(self, cue=''):
        self.update('idle', cue)
        self.headset.close()
        self.dictation = []
        self.playback.clear()
        for task in (self.capture, self.heard, self.speaker):
            if task is not None and task is not asyncio.current_task():
                task.cancel()
        self.capture = None
        self.heard = None

    async def listen(self):
        start = time.monotonic()
        try:
            while self.mode in {'dictation', 'voice'}:
                if time.monotonic() - self.last_ping > 4:
                    self.stop_audio()
                    return
                if self.mode == 'dictation' and time.monotonic() - start >= 120:
                    self.stop_audio('error')
                    return
                while True:
                    try:
                        block = self.headset.samples.get_nowait()
                    except queue.Empty:
                        break
                    if self.mode == 'dictation':
                        self.dictation.append(block)
                    elif not self.headset.muted:
                        blocks = self.utterance.append(block, self.headset.loud(block))
                        if blocks and (self.heard is None or self.heard.done()):
                            self.heard = asyncio.create_task(self.voice_input(blocks))
                await asyncio.sleep(0.05)
        except Exception as error:
            self.report_error(error)
            self.stop_audio('error')

    def finish_dictation(self):
        blocks = self.dictation
        while not self.headset.samples.empty():
            blocks.append(self.headset.samples.get_nowait())
        self.stop_audio()
        self.update('processing')
        self.heard = asyncio.create_task(self.dictation_input(blocks))

    async def dictation_input(self, blocks):
        try:
            text = await asyncio.to_thread(self.headset.transcribe, blocks)
            if not text:
                raise ValueError('No clear speech heard. Try the top half again.')
            self.submit(text)
            self.update('idle', 'sent')
        except Exception as error:
            self.report_error(error)
            self.update('idle', 'error')

    async def voice_input(self, blocks):
        try:
            text = await asyncio.to_thread(self.headset.transcribe, blocks)
            if not text or self.mode != 'voice':
                return
            busy = self.running or bool(self.prompts)
            self.submit(text)
            if busy:
                self.say(self.progress() + ' I queued your message.')
        except Exception as error:
            self.report_error(error)
            self.say('I could not send that message. Please try again.')

    def submit(self, text):
        if not self.connected:
            raise ConnectionError('Codex disconnected.')
        if len(self.prompts) >= 5:
            raise RuntimeError('The prompt queue is full.')
        self.prompts.append(text)
        self.schedule_dispatch()

    def schedule_dispatch(self):
        if self.connected and not self.running and self.prompts and (
            self.dispatcher is None or self.dispatcher.done()
        ):
            self.dispatcher = asyncio.create_task(self.send_next())

    async def send_next(self):
        self.running = True
        self.latest_progress = ''
        text = self.prompts.popleft()
        try:
            await self.rpc.call('turn/start', {
                'threadId': self.thread_id, 'input': [{'type': 'text', 'text': text}],
            })
            print('Codex accepted a spoken prompt.', flush=True)
        except asyncio.TimeoutError:
            # A late server acknowledgement could still start the turn. Never resubmit it.
            self.report_error('Timed out waiting for Codex. Check the round chat before retrying.')
            self.update(cue='error')
            self.say('Codex did not acknowledge the message. Ask the organizer to check.')
        except Exception as error:
            self.report_error(error)
            self.running = False
            self.update(cue='error')
            self.say('Codex could not start that message. Please try again.')
        finally:
            self.dispatcher = None
            self.schedule_dispatch()

    def progress(self):
        return 'Codex is working. ' + self.latest_progress[:280]

    def on_event(self, message):
        method = message.get('method')
        params = message.get('params', {})
        if method == 'bridge/disconnected':
            self.connected = False
            self.stop_audio('error')
            return
        if not self.thread_id or params.get('threadId') != self.thread_id:
            return
        if method == 'turn/started':
            self.running = True
            self.latest_progress = ''
        elif method == 'item/completed' and params.get('item', {}).get('type') == 'agentMessage':
            self.latest_progress = params['item'].get('text', '')
        elif method == 'turn/completed':
            self.running = False
            status = params['turn']['status']
            print(f'Codex turn {status}.', flush=True)
            if status == 'completed':
                self.say(self.latest_progress or 'Codex finished the turn.')
            else:
                self.update(cue='error')
                self.say('The Codex turn ended early. Ask the organizer to check the chat.')
            self.schedule_dispatch()

    def say(self, text):
        if self.mode != 'voice':
            return
        self.playback.append(text)
        if self.speaker is None or self.speaker.done():
            self.speaker = asyncio.create_task(self.speak())

    async def speak(self):
        self.headset.muted = True
        self.headset.clear()
        self.utterance.reset()
        try:
            while self.playback and self.mode == 'voice':
                await self.headset.speak(self.playback.popleft())
            await asyncio.sleep(0.25)
        except Exception as error:
            self.report_error(error)
            self.update(cue='error')
        finally:
            self.headset.muted = False
            self.speaker = None
            if self.mode == 'voice' and self.playback:
                self.speaker = asyncio.create_task(self.speak())

    @staticmethod
    def report_error(error):
        print(f'Round: {error}', file=sys.stderr, flush=True)


def serve(round_session, loop, code):
    actions = {'/dictation/start', '/dictation/stop', '/voice/start', '/voice/stop'}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.handle_route(self.path == '/status')

        def do_POST(self):
            self.handle_route(self.path in actions)

        def handle_route(self, valid):
            provided = self.headers.get('Authorization', '').encode()
            if not hmac.compare_digest(provided, f'Bearer {code}'.encode()):
                self.send_error(403)
                return
            if not valid:
                self.send_error(404)
                return
            work = asyncio.run_coroutine_threadsafe(round_session.request(self.path), loop)
            try:
                result = json.dumps(work.result(timeout=1.3)).encode()
            except TimeoutError:
                work.cancel()
                self.send_error(503)
                return
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(result)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            try:
                self.wfile.write(result)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def log_message(self, _format, *_args):
            pass

    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


async def check_workspace(rpc, workspace):
    marker = workspace / f'.blindfold-check-{secrets.token_hex(8)}.txt'
    try:
        result = await rpc.call('command/exec', {
            'command': ['cmd.exe', '/d', '/c', f'echo blindfold-ready>{marker.name}'],
            'cwd': str(workspace), 'timeoutMs': 10000,
            'sandboxPolicy': {'type': 'workspaceWrite', 'writableRoots': [str(workspace)],
                              'networkAccess': False, 'excludeTmpdirEnvVar': True, 'excludeSlashTmp': True},
        })
        if result['exitCode'] != 0 or not marker.is_file():
            raise RuntimeError(result.get('stderr') or 'The test file was not created.')
    except Exception as error:
        raise RuntimeError(f'Codex could not write inside this folder with its Windows sandbox. {error}') from error
    finally:
        marker.unlink(missing_ok=True)


async def main(args):
    workspace = Path(args.workspace).resolve(strict=True)
    if not workspace.is_dir():
        raise ValueError('Choose a project folder for the round.')
    print('Preparing microphone and local speech recognition…', flush=True)
    session = Round(await asyncio.to_thread(Headset, args.language, args.mic_threshold))
    session.rpc = await CodexRpc.start(args.codex, session.on_event)
    server = None
    try:
        await check_workspace(session.rpc, workspace)
        params = {'cwd': str(workspace), 'sandbox': 'workspace-write', 'approvalPolicy': 'never',
                  'developerInstructions': VOICE_INSTRUCTIONS}
        if args.resume:
            result = await session.rpc.call('thread/resume', {**params, 'threadId': args.resume})
            if result['thread'].get('status', {}).get('type') == 'active':
                raise RuntimeError('Wait for the existing turn to finish before resuming this chat.')
        else:
            result = await session.rpc.call('thread/start', params)
        session.thread_id = result['thread']['id']
        code = f'{secrets.randbelow(10**10):010d}'
        server = serve(session, asyncio.get_running_loop(), code)
        print(f'Round folder: {workspace}\nCodex chat: codex://threads/{session.thread_id}', flush=True)
        print(f'On the phone, enter pairing code {code}.\nKeep this window open. Ctrl+C ends the bridge.', flush=True)
        await session.rpc.process.wait()
        raise ConnectionError('The Codex app server exited.')
    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        session.stop_audio()
        await session.rpc.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run a blindfold hackathon round.')
    parser.add_argument('--workspace', required=True, help='Dedicated folder for the round')
    parser.add_argument('--resume', help='Idle local Codex thread ID from a previous launch')
    parser.add_argument('--language', default=None, help='Whisper language code, such as en or te')
    parser.add_argument('--mic-threshold', default=0.012, type=float, help='Speech threshold (0 to 1)')
    parser.add_argument('--codex', default='codex', help='Path to the Codex executable')
    args = parser.parse_args()
    try:
        asyncio.run(main(args))
    except KeyboardInterrupt:
        pass
    except Exception as error:
        Round.report_error(error)
        sys.exit(1)
