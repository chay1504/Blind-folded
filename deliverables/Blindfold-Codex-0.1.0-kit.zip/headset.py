import asyncio
from collections import deque
import queue
import re

import numpy as np
import sounddevice
from faster_whisper import WhisperModel

RATE = 16000
BLOCK = 800


class Headset:
    def __init__(self, language, threshold):
        sounddevice.check_input_settings(samplerate=RATE, channels=1, dtype='int16')
        self.model = WhisperModel('tiny', device='cpu', compute_type='int8', cpu_threads=2)
        self.language = language
        self.threshold = threshold
        self.samples = queue.Queue(maxsize=80)
        self.stream = None
        self.muted = False

    def open(self):
        self.clear()
        self.stream = sounddevice.RawInputStream(
            samplerate=RATE, blocksize=BLOCK, channels=1, dtype='int16', callback=self.capture,
        )
        try:
            self.stream.start()
        except BaseException:
            self.close()
            raise

    def capture(self, data, _frames, _time, _status):
        if not self.muted:
            try:
                self.samples.put_nowait(bytes(data))
            except queue.Full:
                pass

    def clear(self):
        while True:
            try:
                self.samples.get_nowait()
            except queue.Empty:
                return

    def close(self):
        if self.stream is not None:
            self.stream.close()
            self.stream = None
        self.clear()

    def loud(self, block):
        signal = np.frombuffer(block, dtype='<i2').astype(np.float32) / 32768
        return np.sqrt(np.mean(signal * signal)) >= self.threshold

    def transcribe(self, blocks):
        if not blocks or sum(self.loud(block) for block in blocks) < 5:
            return ''
        audio = np.frombuffer(b''.join(blocks), dtype='<i2').astype(np.float32) / 32768
        segments, _ = self.model.transcribe(
            audio, language=self.language, beam_size=3, vad_filter=True,
            condition_on_previous_text=False,
        )
        return ' '.join(segment.text.strip() for segment in segments).strip()

    async def speak(self, text):
        clean = re.sub(r'```[\s\S]*?```', ' Code block omitted. ', text)
        clean = re.sub(r'\[([^\]]+)\]\([^\n)]+\)', r'\1', clean)
        clean = ' '.join(clean.replace('`', '').replace('*', '').split())[:1200]
        if not clean:
            return
        command = (
            '[Console]::InputEncoding = [System.Text.Encoding]::UTF8; '
            'Add-Type -AssemblyName System.Speech; '
            '$speaker = New-Object System.Speech.Synthesis.SpeechSynthesizer; '
            '$speaker.Speak([Console]::In.ReadToEnd())'
        )
        process = await asyncio.create_subprocess_exec(
            'powershell.exe', '-NoProfile', '-NonInteractive', '-Command', command,
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        try:
            await asyncio.wait_for(process.communicate(clean.encode()), 55)
            if process.returncode:
                raise RuntimeError('Windows speech playback failed.')
        finally:
            if process.returncode is None:
                process.terminate()
                await process.wait()


class Utterance:
    def __init__(self):
        self.reset()

    def reset(self):
        self.lead_in = deque(maxlen=5)
        self.blocks = []
        self.quiet = 0

    def append(self, block, loud):
        if not self.blocks and not loud:
            self.lead_in.append(block)
            return None
        if not self.blocks:
            self.blocks.extend(self.lead_in)
        self.blocks.append(block)
        self.quiet = 0 if loud else self.quiet + 1
        if self.quiet < 18 and len(self.blocks) < 600:
            return None
        complete = self.blocks
        self.reset()
        return complete
