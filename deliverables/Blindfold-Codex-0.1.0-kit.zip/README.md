# Blindfold Codex

Blindfold Codex lets a participant direct a real Codex coding session from two full-screen Android buttons. The Windows PC runs Codex and handles audio through its default headset. The phone is a USB remote.

## Organizer setup

1. Use a Windows PC with Python 3.12, the Codex CLI signed in to ChatGPT, and [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools) available. Run `codex login status` to check the sign-in. If needed, install the standalone Windows CLI with `npm install --prefix "$env:LOCALAPPDATA\BlindfoldCodex\cli" @openai/codex@0.167.0`. The launcher picks up that copy automatically.
2. From this folder, run `python -m pip install -r requirements.txt`. Allow the local Whisper model to download on the first launch. After that, the speech recognition model is cached. Codex still needs an internet connection.
3. Install the debug APK on an Android 8.0 or newer event phone. Enable USB debugging on the event phone, plug it into the PC with a data cable, and approve the PC on the phone. Keep only one physical Android phone plugged in.
4. Set the PC's default microphone and speaker to the participant's headset. Use a separate project folder for each round. Double-click **Start Round.cmd** and enter that folder. The bridge opens a fresh local Codex conversation and prints its desktop link and a pairing code.
5. Open Blindfold Codex on the phone and enter the code. Dismiss Android's first-use full-screen tip if it appears. Position the phone face-up with its charging cable toward the participant. Do a short dry run with the actual headset and language in the event room before putting on the blindfold.

## During a round

| Where | First tap | Second tap |
| --- | --- | --- |
| Top half | Starts dictation. One short vibration. | Stops, transcribes, and queues the prompt. A short pulse followed by a longer pulse confirms it was queued. |
| Bottom half | Enters voice mode. Two short pulses. Speak after the spoken cue, then pause for about one second. | Ends voice mode. One long pulse. |

Voice mode takes turns. On entry it reads the latest reply or progress if available. The microphone pauses while the headset reads a reply. Prompts from both modes go into the same local Codex conversation. If Codex is already working, the bridge can read its latest progress update and queues the new question or instruction for the next turn. An error produces two long pulses. The phone displays no conversation or code.

The app accepts one audio mode at a time. Dictation sends on the second tap, so rehearse short, clear instructions. If the phone drops out for four seconds, the bridge closes the microphone and discards any unfinished recording. Dictation also stops without submitting if left recording for two minutes. If unplugging cleared the USB connection, plug it back in and run `adb -d reverse tcp:18763 tcp:18763` again. If the bridge was restarted, reopen the APK and enter the fresh code.

For a round in a fixed language, launch `Start-Round.ps1` with `-Language en` for English or `-Language te` for Telugu. The small CPU model can mishear names or code identifiers, and the installed Windows speech voice determines how replies sound. Confirm both work for the event's languages and noise levels in a rehearsal.

## End the round

Open the printed `codex://threads/…` link on the PC to review the conversation. Keep that chat for judging and use the round folder for the demo and tests. The bridge owns the live Codex connection during the round. Use the desktop chat for review after closing the bridge with Ctrl+C. To restart a stopped round, pass the prior ID with `-Resume` and use the same workspace.

Use organizer-owned phones for USB debugging. A round uses Codex's workspace-write sandbox and declines interactive escalation. The bridge checks workspace writes before pairing. If the default Codex executable fails the check, use `Start-Round.ps1 -CodexPath 'C:\path\to\codex.exe'` with a working standalone CLI. See the [Windows sandbox setup guide](https://learn.chatgpt.com/docs/windows/windows-sandbox). If a task needs dependencies or external services, prepare those before the clock starts or have the organizer handle the blocker.

## Build the APK

Set `JAVA_HOME` to JDK 17 and `ANDROID_HOME` to an Android SDK with API 36, then run `gradlew.bat :app:assembleDebug :app:lintDebug`. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
