import asyncio
import json
import os


class CodexRpc:
    def __init__(self, process, on_event):
        self.process = process
        self.on_event = on_event
        self.pending = {}
        self.next_id = 0
        self.reader = asyncio.create_task(self.read())

    @classmethod
    async def start(cls, executable, on_event):
        # This is a standalone CLI child, even when the organizer opens it from Codex.
        env = os.environ.copy()
        env.pop('CODEX_WINDOWS_REGISTERED_CORE', None)
        env.pop('CODEX_WINDOWS_SANDBOX_PACKAGE_FAMILY', None)
        process = await asyncio.create_subprocess_exec(
            executable, 'app-server',
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL, limit=16 * 1024 * 1024, env=env,
        )
        rpc = cls(process, on_event)
        try:
            await rpc.call('initialize', {'clientInfo': {
                'name': 'blindfold_codex', 'title': 'Blindfold Codex', 'version': '0.1.0',
            }})
            await rpc.send({'method': 'initialized', 'params': {}})
        except BaseException:
            await rpc.close()
            raise
        return rpc

    async def send(self, message):
        self.process.stdin.write((json.dumps(message) + '\n').encode())
        await self.process.stdin.drain()

    async def call(self, method, params):
        self.next_id += 1
        request_id = self.next_id
        future = asyncio.get_running_loop().create_future()
        self.pending[request_id] = future
        try:
            await self.send({'id': request_id, 'method': method, 'params': params})
            return await asyncio.wait_for(future, timeout=30)
        finally:
            self.pending.pop(request_id, None)

    async def read(self):
        try:
            async for line in self.process.stdout:
                message = json.loads(line)
                if 'id' not in message:
                    self.on_event(message)
                elif 'method' in message:
                    # Organizer setup uses sandboxed workspace writes and no interactive approvals.
                    await self.send({'id': message['id'], 'error': {
                        'code': -32601, 'message': 'Interactive requests are unavailable in round mode.',
                    }})
                else:
                    future = self.pending.get(message['id'])
                    if future and not future.done():
                        if 'error' in message:
                            future.set_exception(RuntimeError(message['error']['message']))
                        else:
                            future.set_result(message.get('result'))
        finally:
            for future in self.pending.values():
                if not future.done():
                    future.set_exception(ConnectionError('The Codex app server disconnected.'))
            self.on_event({'method': 'bridge/disconnected', 'params': {}})

    async def close(self):
        if self.process.returncode is None:
            self.process.terminate()
        await self.process.wait()
        await asyncio.gather(self.reader, return_exceptions=True)
