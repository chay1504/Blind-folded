@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Round.ps1" %*
pause
